package com.example.coffres

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val p = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(p, p, p, p)
        }
        col.addView(TextView(this).apply {
            text = "Compteur de coffres"
            textSize = 26f
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "Appuie sur Démarrer, puis lance Fortnite. Le compteur reste affiché par-dessus le jeu. Déplace-le avec « ≡ déplacer »."
            gravity = Gravity.CENTER
            setPadding(0, p, 0, p)
        })
        col.addView(Button(this).apply {
            text = "Démarrer"
            setOnClickListener { start() }
        })
        col.addView(Button(this).apply {
            text = "Arrêter"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
