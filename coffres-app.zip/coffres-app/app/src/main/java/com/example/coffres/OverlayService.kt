package com.example.coffres

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var count: TextView
    private lateinit var stats: TextView
    private var box: View? = null

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("coffres", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        show()
    }

    override fun onDestroy() {
        box?.let { wm.removeView(it) }
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("coffres", "Compteur", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "coffres")
            .setSmallIcon(android.R.drawable.ic_menu_add)
            .setContentTitle("Compteur de coffres actif")
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, color: Int, w: Int, h: Int, size: Float, onClick: () -> Unit) =
        Button(this).apply {
            text = t
            textSize = size
            isAllCaps = false
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat(); setColor(color)
            }
            layoutParams = LinearLayout.LayoutParams(dp(w), dp(h)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) }
            setOnClickListener { onClick() }
        }

    private fun show() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(20)); y = prefs.getInt("y", dp(120))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(2), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0xCC111111.toInt())
            }
        }

        val handle = TextView(this).apply {
            text = "≡ déplacer"
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(6))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP -> prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            true
        }

        count = TextView(this).apply {
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = dp(60)
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(btn("−", 0xFF6B7280.toInt(), 56, 52, 24f) { change(-1) })
        row.addView(count)
        row.addView(btn("+", 0xFF7C3AED.toInt(), 56, 52, 24f) { change(1) })

        stats = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
        }

        root.addView(handle)
        root.addView(row)
        root.addView(stats)
        root.addView(btn("Reset", 0xFFDC2626.toInt(), 110, 38, 14f) { endGame() })

        box = root
        wm.addView(root, lp)
        refresh()
    }

    private fun change(d: Int) {
        val c = maxOf(0, prefs.getInt("cur", 0) + d)
        prefs.edit().putInt("cur", c).apply()
        refresh()
    }

    // Reset = fin de game : la game est comptée, ses coffres vont dans le total
    private fun endGame() {
        prefs.edit()
            .putInt("games", prefs.getInt("games", 0) + 1)
            .putInt("total", prefs.getInt("total", 0) + prefs.getInt("cur", 0))
            .putInt("cur", 0)
            .apply()
        refresh()
    }

    private fun refresh() {
        val c = prefs.getInt("cur", 0)
        count.text = c.toString()
        stats.text = "Parties : ${prefs.getInt("games", 0)} · Total : ${prefs.getInt("total", 0) + c}"
    }
}
